export const environment = {
  production: true,
  baseUrl   : "http://bisema.com:8080/" 
};
